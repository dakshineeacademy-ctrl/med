import React, { useState, useMemo } from 'react';
import { CalculatorState, CollegeType } from './types';
import { MOCK_COLLEGES } from './constants';
import CalculatorForm from './components/CalculatorForm';
import CollegeCard from './components/CollegeCard';
import AICounselor from './components/AICounselor';
import { Stethoscope, AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  const [inputs, setInputs] = useState<CalculatorState>({
    score: 550,
    selectedState: 'All India',
    selectedType: 'All Types',
    budgetMax: 100000000 // 10 Cr default (no limit)
  });

  const filteredColleges = useMemo(() => {
    return MOCK_COLLEGES.filter(college => {
      // 1. Filter by State
      const stateMatch = inputs.selectedState === 'All India' || college.state === inputs.selectedState;
      
      // 2. Filter by Type
      const typeMatch = inputs.selectedType === 'All Types' || college.type === inputs.selectedType;

      // 3. Filter by Budget (Total Course Fee approx)
      const courseDuration = 4.5;
      const totalFee = 
        (college.fees.tuitionPerYear * courseDuration) + 
        (college.fees.hostelPerYear * courseDuration) + 
        (college.fees.messPerYear * courseDuration) + 
        (college.fees.otherAnnualFees * courseDuration) + 
        college.fees.admissionFeeOneTime;
      
      const budgetMatch = totalFee <= inputs.budgetMax;

      // 4. Score Logic (Show colleges where score is within reasonable range or greater)
      // Usually users want to see colleges they qualify for (Score >= Cutoff)
      // But we can also show ambitious ones (Score >= Cutoff - 50)
      const scoreMatch = inputs.score >= (college.cutoffScore - 50);

      return stateMatch && typeMatch && budgetMatch && scoreMatch;
    }).sort((a, b) => {
        // Sort by probability (closest cutoff) then by rank
        const aDiff = inputs.score - a.cutoffScore;
        const bDiff = inputs.score - b.cutoffScore;
        // Prioritize colleges where user clears cutoff, then by Ranking
        if (aDiff >= 0 && bDiff < 0) return -1;
        if (bDiff >= 0 && aDiff < 0) return 1;
        return a.ranking - b.ranking;
    });
  }, [inputs]);

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-emerald-600 p-2 rounded-lg text-white">
              <Stethoscope className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">MedFee India</h1>
              <p className="text-xs text-slate-500 font-medium">MBBS Fee Calculator & Predictor</p>
            </div>
          </div>
          <div className="hidden md:block text-sm text-slate-500">
            Updated for 2025-26 Academic Session
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Intro */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Calculate Your MBBS Expenses</h2>
          <p className="text-lg text-slate-600">
            Estimate total course fees including tuition, hostel, and mess charges based on your NEET score and preferred state.
          </p>
        </div>

        {/* Form */}
        <CalculatorForm state={inputs} onChange={setInputs} />

        {/* Results */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-slate-800">
              Eligible Colleges <span className="text-slate-400 font-normal">({filteredColleges.length})</span>
            </h3>
            {filteredColleges.length > 0 && (
                <span className="text-sm text-emerald-600 font-medium bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                   Sorted by Eligibility & Rank
                </span>
            )}
          </div>

          {filteredColleges.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
               <div className="bg-slate-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                 <AlertCircle className="w-8 h-8" />
               </div>
               <h3 className="text-lg font-bold text-slate-800 mb-2">No colleges found matching your criteria</h3>
               <p className="text-slate-500 max-w-md mx-auto">
                 Try adjusting your budget, changing the college type, or lowering the expected score filter to see more results.
               </p>
               <button 
                 onClick={() => setInputs(prev => ({ ...prev, selectedState: 'All India', budgetMax: 100000000 }))}
                 className="mt-6 text-emerald-600 font-semibold hover:text-emerald-700 underline"
               >
                 Clear all filters
               </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredColleges.map((college) => (
                <CollegeCard key={college.id} college={college} />
              ))}
            </div>
          )}
        </div>

        <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-sm text-blue-800 flex gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>
            <strong>Disclaimer:</strong> The fees displayed are approximate based on previous years' data and may vary. 
            Always verify with the official college website or MCC counseling brochure. This tool is for estimation purposes only.
          </p>
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p>&copy; {new Date().getFullYear()} MedFee India. All rights reserved.</p>
          <p className="mt-2">Designed for medical aspirants.</p>
        </div>
      </footer>

      {/* AI Counselor Integration */}
      <AICounselor userScore={inputs.score} userState={inputs.selectedState} />
    </div>
  );
};

export default App;