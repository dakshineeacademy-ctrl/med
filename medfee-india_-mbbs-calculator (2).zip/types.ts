export enum CollegeType {
  GOVERNMENT = 'Government',
  PRIVATE = 'Private',
  DEEMED = 'Deemed University'
}

export enum Quota {
  ALL_INDIA = 'All India Quota',
  STATE = 'State Quota',
  MANAGEMENT = 'Management Quota',
  NRI = 'NRI Quota'
}

export interface FeeStructure {
  tuitionPerYear: number;
  hostelPerYear: number;
  messPerYear: number;
  admissionFeeOneTime: number;
  refundableDeposit: number;
  otherAnnualFees: number;
}

export interface College {
  id: string;
  name: string;
  location: string;
  state: string;
  type: CollegeType;
  cutoffScore: number; // Approximate NEET Score for General
  fees: FeeStructure;
  ranking: number; // NIRF or similar
  website: string;
}

export interface CalculatorState {
  score: number;
  selectedState: string;
  selectedType: string; // 'All' | CollegeType
  budgetMax: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}