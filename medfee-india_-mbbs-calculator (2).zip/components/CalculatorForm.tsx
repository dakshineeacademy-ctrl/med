import React from 'react';
import { STATES, COLLEGE_TYPES } from '../constants';
import { CalculatorState } from '../types';
import { Filter, IndianRupee, MapPin, GraduationCap } from 'lucide-react';

interface Props {
  state: CalculatorState;
  onChange: (newState: CalculatorState) => void;
}

const CalculatorForm: React.FC<Props> = ({ state, onChange }) => {
  
  const handleChange = (field: keyof CalculatorState, value: string | number) => {
    onChange({ ...state, [field]: value });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-slate-100">
      <div className="flex items-center gap-2 mb-6 text-emerald-700">
        <Filter className="w-5 h-5" />
        <h2 className="text-xl font-bold">Filter Options</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* NEET Score */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
            <GraduationCap className="w-4 h-4 text-slate-400" />
            NEET Score (Expected)
          </label>
          <input
            type="number"
            min="0"
            max="720"
            value={state.score}
            onChange={(e) => handleChange('score', parseInt(e.target.value) || 0)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
            placeholder="e.g. 550"
          />
        </div>

        {/* State Selection */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
             <MapPin className="w-4 h-4 text-slate-400" />
             Preferred State
          </label>
          <select
            value={state.selectedState}
            onChange={(e) => handleChange('selectedState', e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white"
          >
            {STATES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        {/* College Type */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-700">College Type</label>
          <select
            value={state.selectedType}
            onChange={(e) => handleChange('selectedType', e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white"
          >
            {COLLEGE_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>

        {/* Budget */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-700 flex items-center gap-1">
            <IndianRupee className="w-4 h-4 text-slate-400" />
            Max Budget (Total Course)
          </label>
          <select
            value={state.budgetMax}
            onChange={(e) => handleChange('budgetMax', parseInt(e.target.value))}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white"
          >
            <option value={100000000}>No Limit</option>
            <option value={500000}>Under ₹5 Lakhs</option>
            <option value={2500000}>Under ₹25 Lakhs</option>
            <option value={5000000}>Under ₹50 Lakhs</option>
            <option value={8000000}>Under ₹80 Lakhs</option>
            <option value={10000000}>Under ₹1 Crore</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default CalculatorForm;