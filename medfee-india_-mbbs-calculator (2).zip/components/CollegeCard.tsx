import React, { useState } from 'react';
import { College, CollegeType } from '../types';
import { ChevronDown, ChevronUp, ExternalLink, MapPin, Building2, Trophy, Info } from 'lucide-react';
import FeeBreakdown from './FeeBreakdown';

interface Props {
  college: College;
}

const CollegeCard: React.FC<Props> = ({ college }) => {
  const [expanded, setExpanded] = useState(false);
  const courseDuration = 4.5; // Academic years

  const totalCourseFee = 
    (college.fees.tuitionPerYear * courseDuration) + 
    (college.fees.hostelPerYear * courseDuration) + 
    (college.fees.messPerYear * courseDuration) + 
    (college.fees.otherAnnualFees * courseDuration) + 
    college.fees.admissionFeeOneTime + 
    college.fees.refundableDeposit;

  const formatMoney = (amount: number) => 
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);

  const getTypeColor = (type: CollegeType) => {
    switch (type) {
      case CollegeType.GOVERNMENT: return 'bg-emerald-100 text-emerald-800';
      case CollegeType.PRIVATE: return 'bg-blue-100 text-blue-800';
      case CollegeType.DEEMED: return 'bg-purple-100 text-purple-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden transition-all hover:shadow-lg">
      <div className="p-5">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-2 py-0.5 rounded text-xs font-semibold ${getTypeColor(college.type)}`}>
                {college.type}
              </span>
              {college.ranking > 0 && (
                <span className="flex items-center gap-1 text-xs text-amber-600 font-medium bg-amber-50 px-2 py-0.5 rounded">
                  <Trophy className="w-3 h-3" /> Rank #{college.ranking}
                </span>
              )}
            </div>
            <h3 className="text-lg font-bold text-slate-900 leading-tight mb-1">{college.name}</h3>
            <p className="text-slate-500 text-sm flex items-center gap-1">
              <MapPin className="w-3 h-3" /> {college.location}, {college.state}
            </p>
          </div>
          <div className="text-right">
             <div className="text-xs text-slate-500 mb-0.5">Approx. Total Cost</div>
             <div className="text-xl font-bold text-slate-900">{formatMoney(totalCourseFee)}</div>
             <div className="text-xs text-slate-400">for 4.5 years</div>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between text-sm">
           <div className="flex gap-4">
             <div className="text-slate-600">
               <span className="block text-xs text-slate-400">Last Year Cutoff</span>
               <span className="font-semibold">{college.cutoffScore}+</span>
             </div>
             <div className="text-slate-600">
               <span className="block text-xs text-slate-400">Yearly Tuition</span>
               <span className="font-semibold">{formatMoney(college.fees.tuitionPerYear)}</span>
             </div>
           </div>
           
           <button 
             onClick={() => setExpanded(!expanded)}
             className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium transition-colors"
           >
             {expanded ? 'Hide Details' : 'View Fee Breakdown'}
             {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
           </button>
        </div>
      </div>

      {expanded && (
        <div className="bg-slate-50 p-5 border-t border-slate-100 animation-fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                <Info className="w-4 h-4 text-emerald-500" />
                Detailed Fee Structure
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-600">Tuition Fee (Per Year)</span>
                  <span className="font-medium">{formatMoney(college.fees.tuitionPerYear)}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-600">Hostel Fee (Per Year)</span>
                  <span className="font-medium">{formatMoney(college.fees.hostelPerYear)}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-600">Mess Charges (Per Year)</span>
                  <span className="font-medium">{formatMoney(college.fees.messPerYear)}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-600">Other Annual Fees</span>
                  <span className="font-medium">{formatMoney(college.fees.otherAnnualFees)}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1 bg-slate-100 px-1 rounded">
                  <span className="text-slate-700 font-medium">One Time Admission</span>
                  <span className="font-semibold">{formatMoney(college.fees.admissionFeeOneTime)}</span>
                </div>
                <div className="flex justify-between pt-2">
                  <span className="text-slate-800 font-bold">Total Course Cost (Est.)</span>
                  <span className="text-emerald-700 font-bold text-lg">{formatMoney(totalCourseFee)}</span>
                </div>
              </div>
              <a 
                href={college.website} 
                target="_blank" 
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs text-blue-600 hover:underline mt-4"
              >
                Visit Official Website <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-2 shadow-sm border border-slate-100">
               <h4 className="text-sm font-semibold text-slate-500 mb-2">Cost Distribution</h4>
               <FeeBreakdown fees={college.fees} duration={courseDuration} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CollegeCard;