import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { FeeStructure } from '../types';

interface Props {
  fees: FeeStructure;
  duration: number; // usually 4.5
}

const COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6'];

const FeeBreakdown: React.FC<Props> = ({ fees, duration }) => {
  const totalTuition = fees.tuitionPerYear * duration;
  const totalHostel = fees.hostelPerYear * duration;
  const totalMess = fees.messPerYear * duration;
  const totalOther = fees.otherAnnualFees * duration;
  const totalOneTime = fees.admissionFeeOneTime + fees.refundableDeposit;

  const data = [
    { name: 'Tuition', value: totalTuition },
    { name: 'Hostel', value: totalHostel },
    { name: 'Mess', value: totalMess },
    { name: 'Other Annual', value: totalOther },
    { name: 'One Time', value: totalOneTime },
  ].filter(d => d.value > 0);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumSignificantDigits: 3
    }).format(value);
  };

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            formatter={(value: number) => formatCurrency(value)}
            contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
          />
          <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default FeeBreakdown;