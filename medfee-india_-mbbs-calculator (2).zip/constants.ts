import { College, CollegeType } from './types';

export const STATES = [
  "All India",
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chandigarh",
  "Chhattisgarh",
  "Delhi",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jammu & Kashmir",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Odisha",
  "Puducherry",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal"
];

export const COLLEGE_TYPES = [
  "All Types",
  CollegeType.GOVERNMENT,
  CollegeType.PRIVATE,
  CollegeType.DEEMED
];

// Comprehensive list of medical colleges in India (Representative List of Top Institutes)
export const MOCK_COLLEGES: College[] = [
  // --- Delhi ---
  {
    id: 'aiims-delhi',
    name: 'All India Institute of Medical Sciences (AIIMS)',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 715,
    ranking: 1,
    website: 'https://www.aiims.edu',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'mamc-delhi',
    name: 'Maulana Azad Medical College (MAMC)',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 700,
    ranking: 32,
    website: 'https://mamc.ac.in',
    fees: { tuitionPerYear: 2400, hostelPerYear: 4000, messPerYear: 40000, admissionFeeOneTime: 1500, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'vmmc-delhi',
    name: 'Vardhman Mahavir Medical College (VMMC)',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 705,
    ranking: 14,
    website: 'http://www.vmmc-sjh.nic.in',
    fees: { tuitionPerYear: 35000, hostelPerYear: 10000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'lhmc-delhi',
    name: 'Lady Hardinge Medical College (LHMC)',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 690,
    ranking: 29,
    website: 'http://lhmc-hosp.gov.in',
    fees: { tuitionPerYear: 1500, hostelPerYear: 4000, messPerYear: 35000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 6000 }
  },
  {
    id: 'ucms-delhi',
    name: 'University College of Medical Sciences (UCMS)',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 695,
    ranking: 30,
    website: 'https://ucms.ac.in',
    fees: { tuitionPerYear: 5000, hostelPerYear: 6000, messPerYear: 36000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 2000 }
  },
  {
    id: 'bsa-delhi',
    name: 'Dr. Baba Saheb Ambedkar Medical College',
    location: 'Rohini, Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 680,
    ranking: 0,
    website: 'http://bsamch.ac.in',
    fees: { tuitionPerYear: 100000, hostelPerYear: 20000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 10000, otherAnnualFees: 15000 }
  },
  {
    id: 'ndmc-delhi',
    name: 'North Delhi Municipal Corporation Medical College',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 675,
    ranking: 0,
    website: 'http://www.northmcd.com/medicalcollege',
    fees: { tuitionPerYear: 50000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'acms-delhi',
    name: 'Army College of Medical Sciences (ACMS)',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.PRIVATE,
    cutoffScore: 600,
    ranking: 50,
    website: 'http://theacms.in',
    fees: { tuitionPerYear: 450000, hostelPerYear: 60000, messPerYear: 50000, admissionFeeOneTime: 15000, refundableDeposit: 20000, otherAnnualFees: 30000 }
  },
  {
    id: 'hamdard-delhi',
    name: 'Hamdard Institute of Medical Sciences',
    location: 'New Delhi',
    state: 'Delhi',
    type: CollegeType.DEEMED,
    cutoffScore: 560,
    ranking: 22,
    website: 'https://www.himsr.co.in',
    fees: { tuitionPerYear: 1600000, hostelPerYear: 150000, messPerYear: 60000, admissionFeeOneTime: 30000, refundableDeposit: 20000, otherAnnualFees: 50000 }
  },

  // --- Andhra Pradesh ---
  {
    id: 'aiims-mangalagiri',
    name: 'AIIMS Mangalagiri',
    location: 'Mangalagiri',
    state: 'Andhra Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 39,
    website: 'https://www.aiimsmangalagiri.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'andhra-mc-vizag',
    name: 'Andhra Medical College',
    location: 'Visakhapatnam',
    state: 'Andhra Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 33,
    website: 'http://amc.edu.in',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'guntur-mc',
    name: 'Guntur Medical College',
    location: 'Guntur',
    state: 'Andhra Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 620,
    ranking: 65,
    website: 'http://gunturmedicalcollege.edu.in',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'kurnool-mc',
    name: 'Kurnool Medical College',
    location: 'Kurnool',
    state: 'Andhra Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 615,
    ranking: 0,
    website: 'http://kurnoolmedicalcollege.edu.in',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'siddhartha-mc',
    name: 'Siddhartha Medical College',
    location: 'Vijayawada',
    state: 'Andhra Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 610,
    ranking: 0,
    website: 'http://smcvja.in',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Assam ---
  {
    id: 'aiims-guwahati',
    name: 'AIIMS Guwahati',
    location: 'Guwahati',
    state: 'Assam',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 0,
    website: 'https://aiimsguwahati.ac.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'gauhati-mc',
    name: 'Gauhati Medical College',
    location: 'Guwahati',
    state: 'Assam',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 620,
    ranking: 60,
    website: 'https://www.gmchassam.gov.in',
    fees: { tuitionPerYear: 24000, hostelPerYear: 10000, messPerYear: 25000, admissionFeeOneTime: 5000, refundableDeposit: 2000, otherAnnualFees: 6000 }
  },
  {
    id: 'assam-mc-dibrugarh',
    name: 'Assam Medical College',
    location: 'Dibrugarh',
    state: 'Assam',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 610,
    ranking: 80,
    website: 'http://assammedicalcollege.in',
    fees: { tuitionPerYear: 24000, hostelPerYear: 10000, messPerYear: 25000, admissionFeeOneTime: 5000, refundableDeposit: 2000, otherAnnualFees: 6000 }
  },

  // --- Bihar ---
  {
    id: 'aiims-patna',
    name: 'AIIMS Patna',
    location: 'Patna',
    state: 'Bihar',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 27,
    website: 'https://aiimspatna.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'pmch-patna',
    name: 'Patna Medical College (PMCH)',
    location: 'Patna',
    state: 'Bihar',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'https://patnamedicalcollege.com',
    fees: { tuitionPerYear: 9000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 2000 }
  },
  {
    id: 'igims-patna',
    name: 'Indira Gandhi Institute of Medical Sciences (IGIMS)',
    location: 'Patna',
    state: 'Bihar',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 640,
    ranking: 0,
    website: 'http://www.igims.org',
    fees: { tuitionPerYear: 120000, hostelPerYear: 24000, messPerYear: 40000, admissionFeeOneTime: 10000, refundableDeposit: 5000, otherAnnualFees: 15000 }
  },
  {
    id: 'nmch-patna',
    name: 'Nalanda Medical College',
    location: 'Patna',
    state: 'Bihar',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 635,
    ranking: 0,
    website: 'http://nmchpatna.org',
    fees: { tuitionPerYear: 9000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 2000 }
  },
  {
    id: 'dmch-darbhanga',
    name: 'Darbhanga Medical College',
    location: 'Darbhanga',
    state: 'Bihar',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 625,
    ranking: 0,
    website: 'http://dmch.ac.in',
    fees: { tuitionPerYear: 9000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 2000 }
  },

  // --- Chandigarh ---
  {
    id: 'gmch-chandigarh',
    name: 'Government Medical College (GMCH)',
    location: 'Chandigarh',
    state: 'Chandigarh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 690,
    ranking: 24,
    website: 'https://gmch.gov.in',
    fees: { tuitionPerYear: 25000, hostelPerYear: 8000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Chhattisgarh ---
  {
    id: 'aiims-raipur',
    name: 'AIIMS Raipur',
    location: 'Raipur',
    state: 'Chhattisgarh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 35,
    website: 'https://www.aiimsraipur.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'pt-jnm-raipur',
    name: 'Pt. JNM Medical College',
    location: 'Raipur',
    state: 'Chhattisgarh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 625,
    ranking: 0,
    website: 'http://www.ptjnmc.in',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },
  {
    id: 'cims-bilaspur',
    name: 'Chhattisgarh Institute of Medical Sciences (CIMS)',
    location: 'Bilaspur',
    state: 'Chhattisgarh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 615,
    ranking: 0,
    website: 'http://www.cimsbilaspur.ac.in',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },

  // --- Gujarat ---
  {
    id: 'aiims-rajkot',
    name: 'AIIMS Rajkot',
    location: 'Rajkot',
    state: 'Gujarat',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 0,
    website: 'https://aiimsrajkot.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'bj-ahmedabad',
    name: 'B.J. Medical College',
    location: 'Ahmedabad',
    state: 'Gujarat',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 40,
    website: 'http://www.bjmc.org',
    fees: { tuitionPerYear: 25000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gmc-surat',
    name: 'Government Medical College',
    location: 'Surat',
    state: 'Gujarat',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'http://www.gmcsurat.edu.in',
    fees: { tuitionPerYear: 25000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gmc-vadodara',
    name: 'Medical College Baroda',
    location: 'Vadodara',
    state: 'Gujarat',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'http://www.medicalcollegebaroda.edu.in',
    fees: { tuitionPerYear: 25000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'mp-shah-jamnagar',
    name: 'M.P. Shah Government Medical College',
    location: 'Jamnagar',
    state: 'Gujarat',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 0,
    website: 'http://www.mpsgc.org',
    fees: { tuitionPerYear: 25000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Haryana ---
  {
    id: 'pgims-rohtak',
    name: 'Pt. B.D. Sharma PGIMS',
    location: 'Rohtak',
    state: 'Haryana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 35,
    website: 'http://pgimsrohtak.ac.in',
    fees: { tuitionPerYear: 52000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },
  {
    id: 'kalpana-chawla-karnal',
    name: 'Kalpana Chawla Government Medical College',
    location: 'Karnal',
    state: 'Haryana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'http://kcgmc.edu.in',
    fees: { tuitionPerYear: 52000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },
  {
    id: 'esic-faridabad',
    name: 'ESIC Medical College',
    location: 'Faridabad',
    state: 'Haryana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'https://www.esic.nic.in/medical-college/faridabad',
    fees: { tuitionPerYear: 100000, hostelPerYear: 15000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 10000 }
  },

  // --- Himachal Pradesh ---
  {
    id: 'igmc-shimla',
    name: 'Indira Gandhi Medical College (IGMC)',
    location: 'Shimla',
    state: 'Himachal Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 640,
    ranking: 0,
    website: 'http://www.igmcs.edu.in',
    fees: { tuitionPerYear: 60000, hostelPerYear: 15000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 10000 }
  },
  {
    id: 'rpgmc-tanda',
    name: 'Dr. Rajendra Prasad Govt. Medical College',
    location: 'Tanda',
    state: 'Himachal Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 35,
    website: 'http://rpgmc.ac.in',
    fees: { tuitionPerYear: 60000, hostelPerYear: 15000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 10000 }
  },
  {
    id: 'aiims-bilaspur',
    name: 'AIIMS Bilaspur',
    location: 'Bilaspur',
    state: 'Himachal Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 0,
    website: 'https://www.aiimsbilaspur.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },

  // --- Jammu & Kashmir ---
  {
    id: 'aiims-jammu',
    name: 'AIIMS Jammu',
    location: 'Vijaypur',
    state: 'Jammu & Kashmir',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 0,
    website: 'https://www.aiimsjammu.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'gmc-srinagar',
    name: 'Government Medical College',
    location: 'Srinagar',
    state: 'Jammu & Kashmir',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 620,
    ranking: 0,
    website: 'http://www.gmcs.edu.in',
    fees: { tuitionPerYear: 26000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gmc-jammu',
    name: 'Government Medical College',
    location: 'Jammu',
    state: 'Jammu & Kashmir',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 610,
    ranking: 0,
    website: 'http://gmcjammu.nic.in',
    fees: { tuitionPerYear: 26000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Jharkhand ---
  {
    id: 'aiims-deoghar',
    name: 'AIIMS Deoghar',
    location: 'Deoghar',
    state: 'Jharkhand',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'https://www.aiimsdeoghar.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'rims-ranchi',
    name: 'Rajendra Institute of Medical Sciences (RIMS)',
    location: 'Ranchi',
    state: 'Jharkhand',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 635,
    ranking: 0,
    website: 'https://www.rimsranchi.ac.in',
    fees: { tuitionPerYear: 9000, hostelPerYear: 5000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'mgm-jamshedpur',
    name: 'MGM Medical College',
    location: 'Jamshedpur',
    state: 'Jharkhand',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 620,
    ranking: 0,
    website: 'http://mgmmcjamshedpur.org',
    fees: { tuitionPerYear: 9000, hostelPerYear: 5000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Karnataka ---
  {
    id: 'bmcri-bangalore',
    name: 'Bangalore Medical College (BMCRI)',
    location: 'Bangalore',
    state: 'Karnataka',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 12,
    website: 'http://www.bmcri.org',
    fees: { tuitionPerYear: 60000, hostelPerYear: 15000, messPerYear: 36000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },
  {
    id: 'kmc-manipal',
    name: 'Kasturba Medical College (KMC)',
    location: 'Manipal',
    state: 'Karnataka',
    type: CollegeType.DEEMED,
    cutoffScore: 580,
    ranking: 9,
    website: 'https://manipal.edu/kmc-manipal.html',
    fees: { tuitionPerYear: 1780000, hostelPerYear: 120000, messPerYear: 60000, admissionFeeOneTime: 50000, refundableDeposit: 10000, otherAnnualFees: 85000 }
  },
  {
    id: 'st-johns-bangalore',
    name: 'St. John\'s Medical College',
    location: 'Bangalore',
    state: 'Karnataka',
    type: CollegeType.PRIVATE,
    cutoffScore: 620,
    ranking: 13,
    website: 'https://www.stjohns.in',
    fees: { tuitionPerYear: 750000, hostelPerYear: 80000, messPerYear: 45000, admissionFeeOneTime: 30000, refundableDeposit: 10000, otherAnnualFees: 40000 }
  },
  {
    id: 'ms-ramaiah',
    name: 'M.S. Ramaiah Medical College',
    location: 'Bangalore',
    state: 'Karnataka',
    type: CollegeType.PRIVATE,
    cutoffScore: 600,
    ranking: 28,
    website: 'https://msrmc.ac.in',
    fees: { tuitionPerYear: 1092000, hostelPerYear: 100000, messPerYear: 55000, admissionFeeOneTime: 25000, refundableDeposit: 0, otherAnnualFees: 50000 }
  },
  {
    id: 'mysore-mc',
    name: 'Mysore Medical College',
    location: 'Mysore',
    state: 'Karnataka',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 45,
    website: 'http://mmcri.karnataka.gov.in',
    fees: { tuitionPerYear: 60000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 4000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },
  {
    id: 'kims-hubli',
    name: 'Karnataka Institute of Medical Sciences (KIMS)',
    location: 'Hubli',
    state: 'Karnataka',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 615,
    ranking: 0,
    website: 'http://www.kimshubballi.org',
    fees: { tuitionPerYear: 60000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 4000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },
  {
    id: 'vims-bellary',
    name: 'Vijayanagar Institute of Medical Sciences (VIMS)',
    location: 'Bellary',
    state: 'Karnataka',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 610,
    ranking: 0,
    website: 'http://www.vims.ac.in',
    fees: { tuitionPerYear: 60000, hostelPerYear: 12000, messPerYear: 30000, admissionFeeOneTime: 4000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },

  // --- Kerala ---
  {
    id: 'gmc-trivandrum',
    name: 'Government Medical College',
    location: 'Thiruvananthapuram',
    state: 'Kerala',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 35,
    website: 'https://www.tmc.kerala.gov.in',
    fees: { tuitionPerYear: 25000, hostelPerYear: 8000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gmc-kozhikode',
    name: 'Government Medical College',
    location: 'Kozhikode',
    state: 'Kerala',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 42,
    website: 'https://www.govtmedicalcollegekozhikode.ac.in',
    fees: { tuitionPerYear: 25000, hostelPerYear: 8000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gmc-kottayam',
    name: 'Government Medical College',
    location: 'Kottayam',
    state: 'Kerala',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'http://www.kottayammedicalcollege.org',
    fees: { tuitionPerYear: 25000, hostelPerYear: 8000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gmc-thrissur',
    name: 'Government Medical College',
    location: 'Thrissur',
    state: 'Kerala',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'http://www.gmcthrissur.org',
    fees: { tuitionPerYear: 25000, hostelPerYear: 8000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'amrita-kochi',
    name: 'Amrita School of Medicine',
    location: 'Kochi',
    state: 'Kerala',
    type: CollegeType.DEEMED,
    cutoffScore: 500,
    ranking: 8,
    website: 'https://www.amrita.edu',
    fees: { tuitionPerYear: 1900000, hostelPerYear: 110000, messPerYear: 65000, admissionFeeOneTime: 10000, refundableDeposit: 10000, otherAnnualFees: 50000 }
  },

  // --- Madhya Pradesh ---
  {
    id: 'aiims-bhopal',
    name: 'AIIMS Bhopal',
    location: 'Bhopal',
    state: 'Madhya Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 690,
    ranking: 20,
    website: 'https://aiimsbhopal.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'mgm-indore',
    name: 'Mahatma Gandhi Memorial Medical College',
    location: 'Indore',
    state: 'Madhya Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'http://www.mgmmcindore.in',
    fees: { tuitionPerYear: 114000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 10000, otherAnnualFees: 10000 }
  },
  {
    id: 'gmc-bhopal',
    name: 'Gandhi Medical College',
    location: 'Bhopal',
    state: 'Madhya Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'http://www.gmcbhopal.net',
    fees: { tuitionPerYear: 114000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 10000, otherAnnualFees: 10000 }
  },
  {
    id: 'grmc-gwalior',
    name: 'Gajra Raja Medical College',
    location: 'Gwalior',
    state: 'Madhya Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 635,
    ranking: 0,
    website: 'http://www.grmcgwalior.org',
    fees: { tuitionPerYear: 114000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 10000, otherAnnualFees: 10000 }
  },
  {
    id: 'nscb-jabalpur',
    name: 'Netaji Subhash Chandra Bose Medical College',
    location: 'Jabalpur',
    state: 'Madhya Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 0,
    website: 'http://www.nscbmc.ac.in',
    fees: { tuitionPerYear: 114000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 10000, otherAnnualFees: 10000 }
  },

  // --- Maharashtra ---
  {
    id: 'aiims-nagpur',
    name: 'AIIMS Nagpur',
    location: 'Nagpur',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 680,
    ranking: 0,
    website: 'https://aiimsnagpur.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'kem-mumbai',
    name: 'Seth GS Medical College (KEM)',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 680,
    ranking: 11,
    website: 'https://www.kem.edu',
    fees: { tuitionPerYear: 120000, hostelPerYear: 20000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 3000, otherAnnualFees: 15000 }
  },
  {
    id: 'bjmc-pune',
    name: 'B.J. Government Medical College',
    location: 'Pune',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 38,
    website: 'http://www.bjmcpune.org',
    fees: { tuitionPerYear: 115000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 12000 }
  },
  {
    id: 'afmc-pune',
    name: 'Armed Forces Medical College (AFMC)',
    location: 'Pune',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 690,
    ranking: 5,
    website: 'https://www.afmc.nic.in',
    fees: { tuitionPerYear: 1000, hostelPerYear: 0, messPerYear: 20000, admissionFeeOneTime: 10000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'grant-mumbai',
    name: 'Grant Medical College (JJ Hospital)',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 16,
    website: 'https://ggmc.edu.in',
    fees: { tuitionPerYear: 110000, hostelPerYear: 18000, messPerYear: 36000, admissionFeeOneTime: 4000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },
  {
    id: 'ltmmc-sion',
    name: 'Lokmanya Tilak Municipal Medical College (Sion)',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 0,
    website: 'http://www.ltmgh.com',
    fees: { tuitionPerYear: 120000, hostelPerYear: 20000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 15000 }
  },
  {
    id: 'tnmc-nair',
    name: 'Topiwala National Medical College (Nair)',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 0,
    website: 'http://www.tnmcnair.edu.in',
    fees: { tuitionPerYear: 120000, hostelPerYear: 20000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 15000 }
  },
  {
    id: 'cooper-mumbai',
    name: 'HBT Medical College (Cooper)',
    location: 'Mumbai',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 0,
    website: 'http://hbtmc.edu.in',
    fees: { tuitionPerYear: 120000, hostelPerYear: 20000, messPerYear: 40000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 15000 }
  },
  {
    id: 'gmc-nagpur',
    name: 'Government Medical College',
    location: 'Nagpur',
    state: 'Maharashtra',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'http://gmcnagpur.org',
    fees: { tuitionPerYear: 115000, hostelPerYear: 15000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 0, otherAnnualFees: 10000 }
  },
  {
    id: 'dy-patil-pune',
    name: 'Dr. D.Y. Patil Medical College',
    location: 'Pune',
    state: 'Maharashtra',
    type: CollegeType.DEEMED,
    cutoffScore: 350,
    ranking: 15,
    website: 'https://medical.dpu.edu.in',
    fees: { tuitionPerYear: 2600000, hostelPerYear: 250000, messPerYear: 100000, admissionFeeOneTime: 100000, refundableDeposit: 0, otherAnnualFees: 50000 }
  },

  // --- Odisha ---
  {
    id: 'aiims-bhubaneswar',
    name: 'AIIMS Bhubaneswar',
    location: 'Bhubaneswar',
    state: 'Odisha',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 685,
    ranking: 17,
    website: 'https://aiimsbhubaneswar.nic.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'scb-cuttack',
    name: 'SCB Medical College',
    location: 'Cuttack',
    state: 'Odisha',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'https://scbmch.in',
    fees: { tuitionPerYear: 30000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 4000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'mkcg-berhampur',
    name: 'MKCG Medical College',
    location: 'Berhampur',
    state: 'Odisha',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 0,
    website: 'http://www.mkcgmch.org',
    fees: { tuitionPerYear: 30000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 4000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Puducherry ---
  {
    id: 'jipmer-puducherry',
    name: 'JIPMER',
    location: 'Puducherry',
    state: 'Puducherry',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 700,
    ranking: 4,
    website: 'https://jipmer.edu.in',
    fees: { tuitionPerYear: 6000, hostelPerYear: 4000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'mgmcri-puducherry',
    name: 'Mahatma Gandhi Medical College',
    location: 'Puducherry',
    state: 'Puducherry',
    type: CollegeType.DEEMED,
    cutoffScore: 320,
    ranking: 48,
    website: 'https://www.sbvu.ac.in/mgmcri',
    fees: { tuitionPerYear: 2200000, hostelPerYear: 150000, messPerYear: 60000, admissionFeeOneTime: 50000, refundableDeposit: 0, otherAnnualFees: 40000 }
  },

  // --- Punjab ---
  {
    id: 'aiims-bathinda',
    name: 'AIIMS Bathinda',
    location: 'Bathinda',
    state: 'Punjab',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 0,
    website: 'https://aiimsbathinda.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'gmc-amritsar',
    name: 'Government Medical College',
    location: 'Amritsar',
    state: 'Punjab',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 620,
    ranking: 55,
    website: 'https://gmc.edu.in',
    fees: { tuitionPerYear: 80000, hostelPerYear: 15000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 12000 }
  },
  {
    id: 'gmc-patiala',
    name: 'Government Medical College',
    location: 'Patiala',
    state: 'Punjab',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 0,
    website: 'http://www.gmcpatiala.com',
    fees: { tuitionPerYear: 80000, hostelPerYear: 15000, messPerYear: 30000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 12000 }
  },
  {
    id: 'cmc-ludhiana',
    name: 'Christian Medical College (CMC)',
    location: 'Ludhiana',
    state: 'Punjab',
    type: CollegeType.PRIVATE,
    cutoffScore: 600,
    ranking: 30,
    website: 'https://www.cmcludhiana.in',
    fees: { tuitionPerYear: 660000, hostelPerYear: 50000, messPerYear: 40000, admissionFeeOneTime: 20000, refundableDeposit: 10000, otherAnnualFees: 30000 }
  },

  // --- Rajasthan ---
  {
    id: 'aiims-jodhpur',
    name: 'AIIMS Jodhpur',
    location: 'Jodhpur',
    state: 'Rajasthan',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 695,
    ranking: 13,
    website: 'https://www.aiimsjodhpur.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'sms-jaipur',
    name: 'Sawai Man Singh Medical College',
    location: 'Jaipur',
    state: 'Rajasthan',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 40,
    website: 'https://education.rajasthan.gov.in/smsmedicalcollege',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 40000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },
  {
    id: 'spmc-bikaner',
    name: 'Sardar Patel Medical College',
    location: 'Bikaner',
    state: 'Rajasthan',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 60,
    website: 'https://education.rajasthan.gov.in/spmedicalcollege',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 36000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },
  {
    id: 'rnt-udaipur',
    name: 'RNT Medical College',
    location: 'Udaipur',
    state: 'Rajasthan',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'https://education.rajasthan.gov.in/rntmedicalcollege',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 36000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },
  {
    id: 'jln-ajmer',
    name: 'Jawaharlal Nehru Medical College',
    location: 'Ajmer',
    state: 'Rajasthan',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 640,
    ranking: 0,
    website: 'https://education.rajasthan.gov.in/jlnmedicalcollege',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 36000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 8000 }
  },

  // --- Tamil Nadu ---
  {
    id: 'aiims-madurai',
    name: 'AIIMS Madurai',
    location: 'Madurai',
    state: 'Tamil Nadu',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'https://aiimsmadurai.org',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'mmc-chennai',
    name: 'Madras Medical College (MMC)',
    location: 'Chennai',
    state: 'Tamil Nadu',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 10,
    website: 'http://www.mmc.ac.in',
    fees: { tuitionPerYear: 13600, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'stanley-chennai',
    name: 'Stanley Medical College',
    location: 'Chennai',
    state: 'Tamil Nadu',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 40,
    website: 'http://www.stanleymedicalcollege.ac.in',
    fees: { tuitionPerYear: 13600, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'kilpauk-chennai',
    name: 'Kilpauk Medical College',
    location: 'Chennai',
    state: 'Tamil Nadu',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 635,
    ranking: 0,
    website: 'http://www.gkmc.in',
    fees: { tuitionPerYear: 13600, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'madurai-mc',
    name: 'Madurai Medical College',
    location: 'Madurai',
    state: 'Tamil Nadu',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 0,
    website: 'http://www.mdmc.ac.in',
    fees: { tuitionPerYear: 13600, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'cmc-vellore',
    name: 'Christian Medical College (CMC)',
    location: 'Vellore',
    state: 'Tamil Nadu',
    type: CollegeType.PRIVATE,
    cutoffScore: 660,
    ranking: 3,
    website: 'https://www.cmch-vellore.edu',
    fees: { tuitionPerYear: 53000, hostelPerYear: 30000, messPerYear: 45000, admissionFeeOneTime: 10000, refundableDeposit: 5000, otherAnnualFees: 25000 }
  },
  {
    id: 'srmc-chennai',
    name: 'Sri Ramachandra Medical College (SRMC)',
    location: 'Chennai',
    state: 'Tamil Nadu',
    type: CollegeType.DEEMED,
    cutoffScore: 420,
    ranking: 15,
    website: 'https://www.sriramachandra.edu.in',
    fees: { tuitionPerYear: 2500000, hostelPerYear: 200000, messPerYear: 70000, admissionFeeOneTime: 50000, refundableDeposit: 20000, otherAnnualFees: 50000 }
  },

  // --- Telangana ---
  {
    id: 'aiims-bibinagar',
    name: 'AIIMS Bibinagar',
    location: 'Bibinagar',
    state: 'Telangana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 0,
    website: 'https://aiimsbibinagar.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'osmania-hyd',
    name: 'Osmania Medical College',
    location: 'Hyderabad',
    state: 'Telangana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 25,
    website: 'http://osmaniamedicalcollege.org',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'gandhi-hyd',
    name: 'Gandhi Medical College',
    location: 'Hyderabad',
    state: 'Telangana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 30,
    website: 'http://gandhimedicalcollege.org',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'kakatiya-warangal',
    name: 'Kakatiya Medical College',
    location: 'Warangal',
    state: 'Telangana',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 625,
    ranking: 0,
    website: 'http://kmcwgl.com',
    fees: { tuitionPerYear: 15000, hostelPerYear: 6000, messPerYear: 30000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Uttar Pradesh ---
  {
    id: 'aiims-rae-bareli',
    name: 'AIIMS Rae Bareli',
    location: 'Rae Bareli',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 0,
    website: 'https://aiimsrbl.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'aiims-gorakhpur',
    name: 'AIIMS Gorakhpur',
    location: 'Gorakhpur',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 0,
    website: 'https://aiimsgorakhpur.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'kgmc-lucknow',
    name: 'King George\'s Medical University',
    location: 'Lucknow',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 675,
    ranking: 12,
    website: 'https://www.kgmu.org',
    fees: { tuitionPerYear: 54600, hostelPerYear: 6000, messPerYear: 36000, admissionFeeOneTime: 5000, refundableDeposit: 2000, otherAnnualFees: 10000 }
  },
  {
    id: 'ims-bhu-varanasi',
    name: 'Institute of Medical Sciences (BHU)',
    location: 'Varanasi',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 690,
    ranking: 6,
    website: 'https://www.bhu.ac.in/ims',
    fees: { tuitionPerYear: 30000, hostelPerYear: 5000, messPerYear: 35000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'amu-aligarh',
    name: 'Jawaharlal Nehru Medical College (AMU)',
    location: 'Aligarh',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 670,
    ranking: 18,
    website: 'https://www.amu.ac.in',
    fees: { tuitionPerYear: 45000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 3000, refundableDeposit: 0, otherAnnualFees: 7000 }
  },
  {
    id: 'rml-lucknow',
    name: 'Dr. Ram Manohar Lohia Institute',
    location: 'Lucknow',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 40,
    website: 'http://drrmlims.ac.in',
    fees: { tuitionPerYear: 60000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 10000 }
  },
  {
    id: 'gsvm-kanpur',
    name: 'GSVM Medical College',
    location: 'Kanpur',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 55,
    website: 'http://gsvmmedicalcollege.com',
    fees: { tuitionPerYear: 36000, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'mln-prayagraj',
    name: 'Moti Lal Nehru Medical College',
    location: 'Prayagraj',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'http://mlnmc.in',
    fees: { tuitionPerYear: 36000, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },
  {
    id: 'llrm-meerut',
    name: 'Lala Lajpat Rai Memorial Medical College',
    location: 'Meerut',
    state: 'Uttar Pradesh',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'http://llrmmedicalcollege.nic.in',
    fees: { tuitionPerYear: 36000, hostelPerYear: 5000, messPerYear: 30000, admissionFeeOneTime: 2000, refundableDeposit: 0, otherAnnualFees: 5000 }
  },

  // --- Uttarakhand ---
  {
    id: 'aiims-rishikesh',
    name: 'AIIMS Rishikesh',
    location: 'Rishikesh',
    state: 'Uttarakhand',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 680,
    ranking: 22,
    website: 'https://aiimsrishikesh.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'gmc-haldwani',
    name: 'Government Medical College',
    location: 'Haldwani',
    state: 'Uttarakhand',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 630,
    ranking: 0,
    website: 'http://www.gmchld.org',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 10000 }
  },
  {
    id: 'gmc-dehradun',
    name: 'Government Doon Medical College',
    location: 'Dehradun',
    state: 'Uttarakhand',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 635,
    ranking: 0,
    website: 'http://www.doonmedical.org',
    fees: { tuitionPerYear: 50000, hostelPerYear: 10000, messPerYear: 35000, admissionFeeOneTime: 5000, refundableDeposit: 5000, otherAnnualFees: 10000 }
  },

  // --- West Bengal ---
  {
    id: 'aiims-kalyani',
    name: 'AIIMS Kalyani',
    location: 'Kalyani',
    state: 'West Bengal',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 665,
    ranking: 0,
    website: 'https://aiimskalyani.edu.in',
    fees: { tuitionPerYear: 1628, hostelPerYear: 990, messPerYear: 35000, admissionFeeOneTime: 25, refundableDeposit: 0, otherAnnualFees: 4000 }
  },
  {
    id: 'mc-kolkata',
    name: 'Medical College Kolkata',
    location: 'Kolkata',
    state: 'West Bengal',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 660,
    ranking: 35,
    website: 'https://www.medicalcollegekolkata.in',
    fees: { tuitionPerYear: 9000, hostelPerYear: 4000, messPerYear: 24000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 3000 }
  },
  {
    id: 'ipgmer-kolkata',
    name: 'IPGMER (SSKM)',
    location: 'Kolkata',
    state: 'West Bengal',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 655,
    ranking: 38,
    website: 'http://www.ipgmer.gov.in',
    fees: { tuitionPerYear: 9000, hostelPerYear: 4000, messPerYear: 24000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 3000 }
  },
  {
    id: 'nrs-kolkata',
    name: 'Nil Ratan Sircar Medical College',
    location: 'Kolkata',
    state: 'West Bengal',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 650,
    ranking: 0,
    website: 'http://nrsmc.edu.in',
    fees: { tuitionPerYear: 9000, hostelPerYear: 4000, messPerYear: 24000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 3000 }
  },
  {
    id: 'rg-kar-kolkata',
    name: 'R.G. Kar Medical College',
    location: 'Kolkata',
    state: 'West Bengal',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 645,
    ranking: 0,
    website: 'http://rgkarmch.org',
    fees: { tuitionPerYear: 9000, hostelPerYear: 4000, messPerYear: 24000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 3000 }
  },
  {
    id: 'cnmc-kolkata',
    name: 'Calcutta National Medical College',
    location: 'Kolkata',
    state: 'West Bengal',
    type: CollegeType.GOVERNMENT,
    cutoffScore: 640,
    ranking: 0,
    website: 'https://cnmckolkata.in',
    fees: { tuitionPerYear: 9000, hostelPerYear: 4000, messPerYear: 24000, admissionFeeOneTime: 1000, refundableDeposit: 0, otherAnnualFees: 3000 }
  },
  {
    id: 'kpc-kolkata',
    name: 'KPC Medical College',
    location: 'Kolkata',
    state: 'West Bengal',
    type: CollegeType.PRIVATE,
    cutoffScore: 580,
    ranking: 80,
    website: 'https://kpcmedicalcollege.org',
    fees: { tuitionPerYear: 450000, hostelPerYear: 80000, messPerYear: 40000, admissionFeeOneTime: 50000, refundableDeposit: 0, otherAnnualFees: 20000 }
  }
];
