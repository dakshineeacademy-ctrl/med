import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getCounselingAdvice = async (
  query: string, 
  userScore: number, 
  userState: string
): Promise<string> => {
  try {
    const systemInstruction = `
      You are an expert MBBS Admission Counselor for India.
      The user has a NEET Score of ${userScore} and is from ${userState}.
      Provide concise, accurate, and helpful advice regarding medical college admissions, fee structures, bonds, and career prospects in India.
      If asked about cutoff predictions, be realistic but encouraging. Mention that cutoffs vary every year.
      Format your response in Markdown.
      Keep the tone professional yet empathetic.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: query,
      config: {
        systemInstruction: systemInstruction,
        thinkingConfig: { thinkingBudget: 0 } 
      }
    });

    return response.text || "I apologize, I couldn't generate a response at this moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, our AI counselor is currently experiencing high traffic. Please try again later.";
  }
};
